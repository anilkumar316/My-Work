# AI Customer Support Chatbot

A modern, AI-powered customer support chatbot built with React, Node.js, OpenAI API, and MongoDB.

## Features

- 🤖 AI-powered responses using OpenAI GPT
- 💬 Real-time chat interface
- 📊 Conversation history and analytics
- 🔒 Secure API with rate limiting
- 📱 Responsive design
- 🐳 Docker support
- 📈 Performance monitoring

## Tech Stack

- **Frontend**: React 18, CSS3, Axios
- **Backend**: Node.js, Express.js, MongoDB
- **AI**: OpenAI GPT-3.5/4 API
- **DevOps**: Docker, Docker Compose

## Quick Start

### Prerequisites

- Node.js (v16 or higher)
- MongoDB (v4.4 or higher)
- OpenAI API key

### Installation

1. Clone the repository:
```bash
git clone <your-repository>
cd AI-Customer-Support-Chatbot
```

2. Install dependencies:
```bash
# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

3. Set up environment variables:
```bash
# Server environment
cp server/.env.example server/.env
# Add your OpenAI API key and MongoDB URI

# Client environment  
cp client/.env.example client/.env
```

4. Start the application:
```bash
# Start MongoDB (if running locally)
mongod

# Start the backend server (Terminal 1)
cd server
npm run dev

# Start the frontend (Terminal 2)
cd client
npm start
```

The application will be available at `http://localhost:3000`

## Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up --build

# Or for production
docker-compose -f docker-compose.yml up --build
```

## API Endpoints

- `POST /api/chat` - Send a message to the chatbot
- `GET /api/chat/history/:sessionId` - Get chat history
- `DELETE /api/chat/session/:sessionId` - Delete chat session
- `GET /api/health` - Health check endpoint

## Environment Variables

### Server (.env)
```
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/chatbot
OPENAI_API_KEY=your_openai_api_key_here
CORS_ORIGIN=http://localhost:3000
```

### Client (.env)
```
REACT_APP_API_URL=http://localhost:5000/api
```

## Project Structure

```
AI-Customer-Support-Chatbot/
├── client/                 # React frontend
│   ├── public/
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── services/       # API services
│   │   └── styles/         # CSS files
│   └── package.json
├── server/                 # Node.js backend
│   ├── config/            # Database configuration
│   ├── controllers/       # Route controllers
│   ├── models/           # MongoDB models
│   ├── routes/           # API routes
│   ├── services/         # Business logic
│   ├── utils/            # Utilities
│   └── package.json
├── docker-compose.yml     # Docker configuration
└── README.md
```

## Features Implemented

### Core Features
- ✅ Real-time chat interface
- ✅ AI-powered responses
- ✅ Conversation history storage
- ✅ Session management
- ✅ Error handling and loading states
- ✅ Responsive design

### Advanced Features
- ✅ Rate limiting
- ✅ Intent analysis
- ✅ Logging and monitoring
- ✅ Docker support
- ✅ Health check endpoints
- ✅ Security middleware

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License.

## Support

If you have any questions or need help, please open an issue on GitHub.

---

**Built with ❤️ by [Your Name]**

*Created on September 02, 2025*
