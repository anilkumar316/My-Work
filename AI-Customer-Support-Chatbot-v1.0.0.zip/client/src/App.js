import React from 'react';
import ChatBot from './components/ChatBot';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>AI Customer Support</h1>
        <p>Get instant help with our AI-powered assistant</p>
      </header>
      <main className="App-main">
        <ChatBot />
      </main>
    </div>
  );
}

export default App;