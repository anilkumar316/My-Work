import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for adding auth tokens
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 429) {
      console.warn('Rate limit exceeded. Please slow down requests.');
    }
    return Promise.reject(error);
  }
);

export const chatAPI = {
  sendMessage: (data) => api.post('/chat', data),
  getChatHistory: (sessionId) => api.get(`/chat/history/${sessionId}`),
  deleteSession: (sessionId) => api.delete(`/chat/session/${sessionId}`),
};

export default api;