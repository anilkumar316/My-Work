const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  role: {
    type: String,
    enum: ['user', 'assistant'],
    required: true
  },
  content: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  tokenUsage: {
    input: Number,
    output: Number,
    total: Number
  }
});

const ChatSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  userId: {
    type: String,
    required: false
  },
  messages: [MessageSchema],
  metadata: {
    userAgent: String,
    ipAddress: String,
    startedAt: {
      type: Date,
      default: Date.now
    },
    lastActivity: {
      type: Date,
      default: Date.now
    },
    resolved: {
      type: Boolean,
      default: false
    },
    escalated: {
      type: Boolean,
      default: false
    },
    satisfaction: {
      type: Number,
      min: 1,
      max: 5
    }
  },
  analytics: {
    totalMessages: {
      type: Number,
      default: 0
    },
    avgResponseTime: Number,
    containmentRate: Number
  }
}, {
  timestamps: true
});

// Indexes for better query performance
ChatSchema.index({ 'metadata.startedAt': -1 });
ChatSchema.index({ 'metadata.resolved': 1 });
ChatSchema.index({ sessionId: 1, 'metadata.lastActivity': -1 });

// Static methods
ChatSchema.statics.getRecentChats = function(limit = 100) {
  return this.find({})
    .sort({ 'metadata.lastActivity': -1 })
    .limit(limit)
    .select('sessionId metadata.startedAt metadata.resolved analytics')
    .lean();
};

module.exports = mongoose.model('Chat', ChatSchema);