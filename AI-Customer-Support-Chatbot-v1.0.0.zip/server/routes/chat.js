const express = require('express');
const chatController = require('../controllers/chatController');
const router = express.Router();

// Chat routes
router.post('/', chatController.sendMessage);
router.get('/history/:sessionId', chatController.getChatHistory);
router.delete('/session/:sessionId', chatController.deleteSession);

module.exports = router;