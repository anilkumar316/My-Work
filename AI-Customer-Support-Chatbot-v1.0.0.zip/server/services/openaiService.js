const OpenAI = require('openai');
const logger = require('../utils/logger');

class OpenAIService {
  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    this.systemPrompt = `You are a helpful customer support assistant. 
    Your goal is to:
    1. Provide accurate and helpful information
    2. Resolve customer issues efficiently
    3. Maintain a professional and friendly tone
    4. Escalate complex issues when necessary
    5. Keep responses concise but comprehensive

    If you cannot resolve an issue, politely suggest speaking with a human agent.`;
  }

  async generateResponse(messages, options = {}) {
    try {
      const {
        temperature = 0.7,
        maxTokens = 500,
        model = 'gpt-3.5-turbo'
      } = options;

      const completion = await this.openai.chat.completions.create({
        model: model,
        messages: [
          { role: 'system', content: this.systemPrompt },
          ...messages
        ],
        temperature: temperature,
        max_tokens: maxTokens,
        presence_penalty: 0.1,
        frequency_penalty: 0.1
      });

      return {
        content: completion.choices[0].message.content,
        usage: completion.usage,
        model: completion.model
      };
    } catch (error) {
      logger.error('OpenAI API Error:', error);

      if (error.status === 429) {
        throw new Error('Rate limit exceeded. Please try again in a moment.');
      } else if (error.status === 401) {
        throw new Error('Invalid API key configuration.');
      } else {
        throw new Error('Unable to generate response. Please try again.');
      }
    }
  }

  async analyzeIntent(message) {
    try {
      const completion = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `Analyze the user's intent and categorize it. 
            Return a JSON object with: intent, confidence, category.
            Categories: order_status, refund_request, product_info, technical_support, account_issues, general_inquiry`
          },
          { role: 'user', content: message }
        ],
        temperature: 0.3,
        max_tokens: 100
      });

      return JSON.parse(completion.choices[0].message.content);
    } catch (error) {
      logger.error('Intent analysis error:', error);
      return { intent: 'general_inquiry', confidence: 0.5, category: 'general_inquiry' };
    }
  }
}

module.exports = new OpenAIService();