const Chat = require('../models/Chat');
const openaiService = require('../services/openaiService');
const logger = require('../utils/logger');

class ChatController {
  async sendMessage(req, res) {
    try {
      const { message, sessionId } = req.body;

      if (!message || !message.trim()) {
        return res.status(400).json({ error: 'Message is required' });
      }

      // Find or create chat session
      let chat = await Chat.findOne({ sessionId });
      if (!chat) {
        chat = new Chat({
          sessionId,
          metadata: {
            userAgent: req.headers['user-agent'],
            ipAddress: req.ip
          }
        });
      }

      // Add user message to history
      const userMessage = {
        role: 'user',
        content: message.trim(),
        timestamp: new Date()
      };

      chat.messages.push(userMessage);
      chat.metadata.lastActivity = new Date();

      // Analyze intent
      const intent = await openaiService.analyzeIntent(message);

      // Generate AI response
      const conversationHistory = chat.messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      const aiResponse = await openaiService.generateResponse(conversationHistory);

      // Add assistant message to history
      const assistantMessage = {
        role: 'assistant',
        content: aiResponse.content,
        timestamp: new Date(),
        tokenUsage: {
          input: aiResponse.usage.prompt_tokens,
          output: aiResponse.usage.completion_tokens,
          total: aiResponse.usage.total_tokens
        }
      };

      chat.messages.push(assistantMessage);
      chat.analytics.totalMessages = chat.messages.length;

      // Save chat session
      await chat.save();

      logger.info(`Chat message processed for session ${sessionId}`);

      res.json({
        reply: aiResponse.content,
        sessionId: sessionId,
        intent: intent,
        messageCount: chat.messages.length
      });

    } catch (error) {
      logger.error('Chat controller error:', error);
      res.status(500).json({ 
        error: 'An error occurred while processing your message',
        details: process.env.NODE_ENV === 'development' ? error.message : undefined
      });
    }
  }

  async getChatHistory(req, res) {
    try {
      const { sessionId } = req.params;
      const { limit = 50 } = req.query;

      const chat = await Chat.findOne({ sessionId });

      if (!chat) {
        return res.status(404).json({ error: 'Chat session not found' });
      }

      const messages = chat.messages
        .slice(-parseInt(limit))
        .map(msg => ({
          role: msg.role,
          content: msg.content,
          timestamp: msg.timestamp
        }));

      res.json({
        sessionId,
        messages,
        metadata: {
          totalMessages: chat.messages.length,
          startedAt: chat.metadata.startedAt,
          lastActivity: chat.metadata.lastActivity
        }
      });

    } catch (error) {
      logger.error('Get chat history error:', error);
      res.status(500).json({ error: 'Unable to retrieve chat history' });
    }
  }

  async deleteSession(req, res) {
    try {
      const { sessionId } = req.params;

      const result = await Chat.deleteOne({ sessionId });

      if (result.deletedCount === 0) {
        return res.status(404).json({ error: 'Chat session not found' });
      }

      res.json({ message: 'Chat session deleted successfully' });

    } catch (error) {
      logger.error('Delete session error:', error);
      res.status(500).json({ error: 'Unable to delete chat session' });
    }
  }
}

module.exports = new ChatController();