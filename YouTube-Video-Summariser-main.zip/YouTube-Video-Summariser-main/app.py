from flask import Flask, request, jsonify
from youtube_transcript_api import YouTubeTranscriptApi
from transformers import pipeline

app = Flask(__name__)

@app.route('/summary', methods=['GET'])
def summary_api():
    try:
        url = request.args.get('url', '')
        video_id = url.split('=')[1]
        transcript = get_transcript(video_id)
        if transcript:
            summary = get_summary(transcript)
            if summary:
                # Save summary to a text file
                save_to_file(summary, 'summary.txt')
                
                return jsonify({'summary': summary, 'message': 'Summary saved to summary.txt'}), 200
            else:
                return jsonify({'error': 'Failed to generate summary.'}), 500
        else:
            return jsonify({'error': 'Failed to fetch transcript.'}), 500
    except Exception as e:
        return jsonify({'error': f'Error processing request: {str(e)}'}), 500

def get_transcript(video_id):
    try:
        transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
        transcript = ' '.join([d['text'] for d in transcript_list])
        return transcript
    except Exception as e:
        print(f"Error fetching transcript: {e}")
        return None

def get_summary(transcript):
    try:
        summarizer = pipeline('summarization', model='facebook/bart-large-cnn')
        # Adjust max_length dynamically based on input length
        max_length_percentage = 0.8  # Adjust as needed
        max_length = int(len(transcript) * max_length_percentage)
        # Split transcript into smaller segments
        segment_size = 500  # Adjust as needed
        segments = [transcript[i:i + segment_size] for i in range(0, len(transcript), segment_size)]
        summary = ''
        for segment in segments:
            # Adjust max_length for each segment
            segment_max_length = min(max_length, len(segment))
            # Generate summary for each segment
            segment_summary = summarizer(segment, max_length=segment_max_length, min_length=30, do_sample=False)[0]['summary_text']
            summary += segment_summary + ' '
        # Remove non-breaking space characters
        summary = summary.replace('\u00a0', ' ')
        return summary
    except Exception as e:
        print(f"Error generating summary: {e}")
        return None

def save_to_file(text, filename):
    # Replace multiple consecutive spaces with a single space
    formatted_text = ' '.join(text.split())
    
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(formatted_text)

if __name__ == '__main__':
    app.run(debug=True)